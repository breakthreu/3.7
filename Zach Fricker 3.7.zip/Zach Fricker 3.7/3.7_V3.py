from tkinter import *
from functools import partial
import re

# Version 3 // Not yet complete, but will introduce
# the functions which determine the nature of the Booking GUI.

## perhaps possible to use the same function, with differing
## functionality based on the button that has been pressed ?

# User Info
class Info:
    def __init__(self):
        # Formatting
        background_colour = "dark blue"

        # info frame
        self.info_frame = Frame(width=400, height=500, pady=10, bg=background_colour)
        self.info_frame.grid()

        # info heading (row 0)
        self.info_label = Label(self.info_frame, text="Massey University Overnighter",
                                 padx=10, pady=10, font=("Arial", "20","bold"),
                                 bg=background_colour, fg="white")
        self.info_label.grid(row=0)

        # Informational text (row 1)
        self.info_text = Label(self.info_frame, text="Please enter the following" 
                               " information to make your booking.", padx=10,
                               pady=10, font = ("Arial", "14"),
                               bg=background_colour, fg="white")
        self.info_text.grid(row=1)

        # First name entry label (row 2)
        self.fname_label = Label(self.info_frame, text="First Name:", padx=10, pady=10,
                                 font = ("Arial", "14", "italic"), bg=background_colour,
                                 fg="white")
        self.fname_label.grid(row=2)
        
        # First name entry box (row 3)
        self.fname_entry = Entry(self.info_frame, width=40, font="Arial 14 bold")
        self.fname_entry.grid(row=3, pady=10)

        # Last name entry label (row 4)
        self.lname_label = Label(self.info_frame, text="Last Name:", padx=10, pady=10,
                                 font = ("Arial", "14", "italic"), bg=background_colour,
                                 fg="white")
        self.lname_label.grid(row=4)
        
        # First name entry box (row 5)
        self.lname_entry = Entry(self.info_frame, width=40, font="Arial 14 bold")
        self.lname_entry.grid(row=5, pady=10)

        # Phone number entry label (row 6)
        self.phone_label = Label(self.info_frame, text="Phone Number:", padx=10, pady=10,
                                 font = ("Arial", "14", "italic"), bg=background_colour,
                                 fg="white")
        self.phone_label.grid(row=6)
        
        # Phone number entry box (row 7)
        self.phone_entry = Entry(self.info_frame, width=40, font="Arial 14 bold")
        self.phone_entry.grid(row=7, pady=10)

        # Auckland to Palmerston North button (row 8)
        self.a_to_pn_button = Button(self.info_frame, text="Auckland to Palmerston North",
                                  font="Arial 10 bold", bg="gold", padx=10, pady=10,
                                  command=lambda: self.a_to_pn())
        self.a_to_pn_button.grid(row=8, pady=3)

        # Palmerston North to Auckland button (row 9)
        self.pn_to_a_button = Button(self.info_frame, text="Palmerston North to Auckland",
                                  font="Arial 10 bold", bg="gold", padx=10, pady=10,
                                  command=lambda: self.pn_to_a())
        self.pn_to_a_button.grid(row=9, pady=3)

        # Book return button (row 10)
        self.return_button = Button(self.info_frame, text="Book Return",
                                  font="Arial 10 bold", bg="gold", padx=10, pady=10,
                                  command=lambda: self.book_return())
        self.return_button.grid(row=10, pady=3)
    
    # Auckland to Palmerston North function
    def a_to_pn(self):
        direction = "ATOPN"
        Booking(direction)

    def pn_to_a(self):
        direction = "PNTOA"
        Booking(direction)

    def book_return(self):
        direction = "RETURN"
        Booking(direction)

# Booking GUI
class Booking:
    def __init__(self, direction):
        # Formatting
        background_colour = "dark blue"

        # Create box
        self.booking_box = Tk()

        # If users press cross at top, closes booking
        self.booking_box.protocol('WM_DELETE_WINDOW', partial(self.close_booking))

        # Booking frame
        self.booking_frame = Frame(self.booking_box, width=400, height=500, pady=10, bg=background_colour)
        self.booking_frame.grid()

        # Booking heading (row 0)
        self.booking_label = Label(self.booking_frame, text="Booking:",
                                   padx=10, pady=10, font=("Arial", "20","bold"),
                                   bg=background_colour, fg="white")
        self.booking_label.grid(row=0)

        # Determining header
        if direction == "ATOPN":
            header = "Auckland to Palmerston North"
        elif direction == "PNTOA":
            header = "Palmerston North to Auckland"
        else:
            header = "Return Booking"

        # Booking subheading (row 1)
        self.booking_subheading = Label(self.booking_frame, text=header, padx=10,
                                        pady=10, font = ("Arial", "14", "bold"),
                                        bg=background_colour, fg="white")
        self.booking_subheading.grid(row=1)

        # Booking text (row 2)
        self.booking_text = Label(self.booking_frame, text="Write 0 in entry "
                                  "box if you are not booking it.", padx=10,
                                  pady=10, font = "Arial, 14", fg="white",
                                  bg=background_colour)
        self.booking_text.grid(row=2)

        # Chairs entry box label (row 3)
        self.chairs_label = Label(self.booking_frame, text="How many chairs "
                                  "will you book?", padx=10, pady=10,
                                  fg="white", bg=background_colour)
        self.chairs_label.grid(row=3)

        # Chairs entry box (row 4)
        self.chairs_entry = Entry(self.booking_frame, font="Arial 14 bold",
                                  width=10)
        self.chairs_entry.grid(row=4, pady=10)
        
        # Bunks entry box label (row 5)
        self.bunks_label = Label(self.booking_frame, text="How many bunks "
                                 "will you book?", padx=10, pady=10,
                                 fg="white", bg=background_colour)
        self.bunks_label.grid(row=5)

        # Bunks entry box (row 6)
        self.bunks_entry = Entry(self.booking_frame, font="Arial 14 bold",
                                 width=10)
        self.bunks_entry.grid(row=6, pady=10)

        # Buttons frame (row 7)
        self.buttons_frame = Frame(self.booking_frame, bg=background_colour)
        self.buttons_frame.grid(row=7, pady=10)

        # Submit button (column 0)
        self.submit_button = Button(self.buttons_frame, font="Arial 10 bold",
                                    text="Submit", bg="gold", padx=10, pady=10,
                                    command=self.enter_preview)
        self.submit_button.grid(row=0, column=0, padx=3)

        # Exit button (column 1)
        self.exit_button = Button(self.buttons_frame, font="Arial 10 bold",
                                  text="Exit", bg="gold", padx=10, pady=10,
                                  command=partial(self.close_booking))
        self.exit_button.grid(row=0, column=1, padx=3)

    # Function to close booking when cross pressed
    def close_booking(self):
        self.booking_box.destroy()

    # Function to enter preview when submit pressed
    def enter_preview(self):
        self.booking_box.destroy()
        Preview()

# Booking Preview GUI
class Preview:
    def __init__(self):
        # Formatting
        background_colour = "dark blue"
        chairs_cost = chairs * 25
        bunks_cost = bunks * 50
        chairs_text = ("{} chairs have been booked both ways\nat a cost of ${}".format(chairs, chairs_cost))
        bunks_text = ("{} bunks have been booked one way\nat a cost of ${}".format(bunks, bunks_cost))
        total_cost = bunks_cost + chairs_cost
        gst_portion = total_cost - (total_cost / 1.15)
        gst_text = ("After a GST portion of ${},\nthis comes to a total cost of\n${}".format(gst_portion, total_cost))

        self.preview_box = Toplevel()

        # If users press cross at top, closes preview
        self.preview_box.protocol('WM_DELETE_WINDOW', partial(self.close_preview))

        # Preview frame
        self.preview_frame = Frame(width=400, height=500, pady=10, bg=background_colour)
        self.preview_frame.grid()

        # Preview heading (row 0)
        self.preview_label = Label(self.preview_frame, text="Booking Preview",
                                   padx=10, pady=10, font=("Arial", "20","bold"),
                                   bg=background_colour, fg="white")
        self.preview_label.grid(row=0)

        # Preview text A, fname/lname/phone (row 1)
        self.preview_text_A = Label(self.preview_frame, text=("First Name: {} \n"
                                 "Last Name: {} \n Phone Number: {} \n"
                                 .format(fname, lname, phone)), padx=10,
                                 font = ("Arial", "14"),
                                 bg=background_colour, fg="white")
        self.preview_text_A.grid(row=1)

        # Preview text B, chairs booking (row 2)
        self.preview_text_B = Label(self.preview_frame, text=chairs_text, padx=10,
                                  pady=10, font = "Arial, 14", fg="white",
                                  bg=background_colour)
        self.preview_text_B.grid(row=2)

        # Preview text C, bunks booking (row 3)
        self.preview_text_C = Label(self.preview_frame, text=bunks_text, padx=10,
                                  pady=10, font = "Arial, 14", fg="white",
                                  bg=background_colour)
        self.preview_text_C.grid(row=3)

        # Preview text D (row 4)
        self.preview_text_D = Label(self.preview_frame, text=gst_text, padx=10,
                                  pady=10, font = "Arial, 14", fg="white",
                                  bg=background_colour)
        self.preview_text_D.grid(row=4)

        # Buttons frame (row 5)
        self.preview_buttons_frame = Frame(self.preview_frame, bg=background_colour)
        self.preview_buttons_frame.grid(row=5, pady=10)

        # Confirm button (column 0)
        self.confirm_button = Button(self.preview_buttons_frame, font="Arial 10 bold",
                                    text="Confirm", bg="gold", padx=10, pady=10)
        self.confirm_button.grid(row=0, column=0, padx=3)

        # Cancel button (column 1)
        self.cancel_button = Button(self.preview_buttons_frame, font="Arial 10 bold",
                                  text="Cancel", bg="gold", padx=10, pady=10,
                                  command=partial(self.close_preview))
        self.cancel_button.grid(row=0, column=1, padx=3)

    # Close preview box when cross pressed
    def close_preview(self):
        self.preview_box.destroy()

if __name__ == "__main__":
    chairs = 2
    bunks = 2
    root = Tk()
    placeholder = Info()
    root.mainloop()