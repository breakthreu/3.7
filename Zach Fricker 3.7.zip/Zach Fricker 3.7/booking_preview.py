from tkinter import *
from functools import partial
import re

## Booking Preview V1 // Completed formatting
# Fname, Lname and Phone taken from booking GUI
# Sentences for bunks/chair booking formed in function from booking GUI
# GST calculation done and sentence formed in booking GUI

# Booking Preview GUI
class Preview:
    def __init__(self):
        # Formatting
        background_colour = "dark blue"

        self.preview_box = Toplevel()

        # If users press cross at top, closes preview
        self.preview_box.protocol('WM_DELETE_WINDOW', partial(self.close_preview))

        # Preview frame
        self.preview_frame = Frame(width=400, height=500, pady=10, bg=background_colour)
        self.preview_frame.grid()

        # Preview heading (row 0)
        self.preview_label = Label(self.preview_frame, text="Booking Preview",
                                   padx=10, pady=10, font=("Arial", "20","bold"),
                                   bg=background_colour, fg="white")
        self.preview_label.grid(row=0)

        # Preview text A, fname/lname/phone (row 1)
        self.preview_text_A = Label(self.preview_frame, text=("First Name: {} \n"
                                 "Last Name: {} \n Phone Number: {} \n"
                                 .format(fname, lname, phone)), padx=10,
                                 font = ("Arial", "14"),
                                 bg=background_colour, fg="white")
        self.preview_text_A.grid(row=1)

        # Preview text B, chairs booking (row 2)
        self.preview_text_B = Label(self.preview_frame, text=chairs_text, padx=10,
                                  pady=10, font = "Arial, 14", fg="white",
                                  bg=background_colour)
        self.preview_text_B.grid(row=2)

        # Preview text C, bunks booking (row 3)
        self.preview_text_C = Label(self.preview_frame, text=bunks_text, padx=10,
                                  pady=10, font = "Arial, 14", fg="white",
                                  bg=background_colour)
        self.preview_text_C.grid(row=3)

        # Preview text D (row 4)
        self.preview_text_D = Label(self.preview_frame, text=gst_text, padx=10,
                                  pady=10, font = "Arial, 14", fg="white",
                                  bg=background_colour)
        self.preview_text_D.grid(row=4)

        # Buttons frame (row 5)
        self.preview_buttons_frame = Frame(self.preview_frame, bg=background_colour)
        self.preview_buttons_frame.grid(row=5, pady=10)

        # Confirm button (column 0)
        self.confirm_button = Button(self.preview_buttons_frame, font="Arial 10 bold",
                                    text="Confirm", bg="gold", padx=10, pady=10)
        self.confirm_button.grid(row=0, column=0, padx=3)

        # Cancel button (column 1)
        self.cancel_button = Button(self.preview_buttons_frame, font="Arial 10 bold",
                                  text="Cancel", bg="gold", padx=10, pady=10,
                                  command=partial(self.close_preview))
        self.cancel_button.grid(row=0, column=1, padx=3)

    def close_preview(self):
        self.preview_box.destroy()

if __name__ == "__main__":
    # for testing component
    fname = "Zach"
    lname = "Fricker"
    phone = "0800838383"
    chairs_text = "2 chairs have been booked both ways\nat a cost of $100"
    bunks_text = "2 bunks have been booked one way\nat a cost of $100"
    gst_text = "After a GST portion of $26.09,\nthis comes to a total cost of\n$226.09"
    root = Tk()
    placeholder = Preview()
    root.mainloop()