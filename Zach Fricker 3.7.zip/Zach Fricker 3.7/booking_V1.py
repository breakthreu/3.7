from tkinter import *
from functools import partial
import re

# Booking V1 // Completed formatting

# Booking GUI
class Booking:
    def __init__(self):
        # Formatting
        background_colour = "dark blue"

        # Determining header
        if direction == "ATOPN":
            header = "Auckland to Palmerston North"
        elif direction == "PNTOA":
            header = "Palmerston North to Auckland"
        else:
            header = "Return Booking"

        # Booking frame
        self.booking_frame = Frame(width=400, height=500, pady=10, bg=background_colour)
        self.booking_frame.grid()

        # Booking heading (row 0)
        self.booking_label = Label(self.booking_frame, text="Booking:",
                                   padx=10, pady=10, font=("Arial", "20","bold"),
                                   bg=background_colour, fg="white")
        self.booking_label.grid(row=0)

        # Booking subheading (row 1)
        self.booking_subheading = Label(self.booking_frame, text=header, padx=10,
                                        pady=10, font = ("Arial", "14", "bold"),
                                        bg=background_colour, fg="white")
        self.booking_subheading.grid(row=1)

        # Booking text (row 2)
        self.booking_text = Label(self.booking_frame, text="Write 0 in entry "
                                  "box if you are not booking it.", padx=10,
                                  pady=10, font = "Arial, 14", fg="white",
                                  bg=background_colour)
        self.booking_text.grid(row=2)

        # Chairs entry box label (row 3)
        self.chairs_label = Label(self.booking_frame, text="How many chairs "
                                  "will you book?", padx=10, pady=10,
                                  fg="white", bg=background_colour)
        self.chairs_label.grid(row=3)

        # Chairs entry box (row 4)
        self.chairs_entry = Entry(self.booking_frame, font="Arial 14 bold",
                                  width=10)
        self.chairs_entry.grid(row=4, pady=10)
        
        # Bunks entry box label (row 5)
        self.bunks_label = Label(self.booking_frame, text="How many bunks "
                                 "will you book?", padx=10, pady=10,
                                 fg="white", bg=background_colour)
        self.bunks_label.grid(row=5)

        # Bunks entry box (row 6)
        self.bunks_entry = Entry(self.booking_frame, font="Arial 14 bold",
                                 width=10)
        self.bunks_entry.grid(row=6, pady=10)

        # Buttons frame (row 7)
        self.buttons_frame = Frame(self.booking_frame, bg=background_colour)
        self.buttons_frame.grid(row=7, pady=10)

        # Submit button (column 0)
        self.submit_button = Button(self.buttons_frame, font="Arial 10 bold",
                                    text="Submit", bg="gold", padx=10, pady=10)
        self.submit_button.grid(row=0, column=0, padx=3)

        # Exit button (column 1)
        self.exit_button = Button(self.buttons_frame, font="Arial 10 bold",
                                  text="Exit", bg="gold", padx=10, pady=10)
        self.exit_button.grid(row=0, column=1, padx=3)

if __name__ == "__main__":
    direction = "RETURN" # for testing this component.
    root = Tk()
    root.title = "Massey University Overnighter"
    placeholder = Booking()
    root.mainloop()