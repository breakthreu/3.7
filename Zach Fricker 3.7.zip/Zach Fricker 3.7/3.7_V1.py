from tkinter import *

# Start GUI
class Start:
    def __init__(self):

        # Start frame
        self.start_frame = Frame(width=700, height=500, bg="dark blue")
        self.start_frame.grid()

        # Start heading (row 0)
        self.start_label = Label(text="Massey University Overnighter",
                                 padx=10, pady=10, font=("Arial", "20","bold"),
                                 bg="dark blue", fg="white")
        self.start_label.grid(row=0)

        # Informational text (row 1)
        self.start_text = Label(text="This program is used to book reclining chairs \n"
                                "and/or bunks on Go Student Bus' Massey Overnighter, \n"
                                "which travels every Friday evening from Palmerston \n"
                                "North to Auckland and every Sunday evening from \n"
                                "Auckland to Palmerston North.", padx=10, pady=10,
                                font = ("Arial", "14"), bg="dark blue", fg="white",
                                wrap=250, justify=LEFT)
        self.start_text.grid(row=1)

        # Start button frame (row 2)
        self.start_button_frame = Frame(self.start_frame)
        self.start_button_frame.grid(row=2, pady=10)

        self.start_continue_button = Button(self.start_button_frame,
                                            command=lambda: self.cont(1))
        
        def cont(self):
            User_Info(self)
        

class User_Info:
    def __init__(self):
        self.info_frame = Frame(width=700, height=500, bg="dark blue")
        self.info_frame.grid()


if __name__ == "__main__":
    root = Tk()
    root.title = "Massey University Overnighter"
    placeholder = Start()
    root.mainloop()