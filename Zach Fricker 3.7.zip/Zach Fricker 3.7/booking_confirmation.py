from tkinter import *
from functools import partial
import re

## Booking confirmation // completed formatting

# Booking Confirmation GUI
class Confirmation:
    def __init__(self):
        # Formatting
        background_colour = "gold"

        self.confirmation_box = Toplevel()

        # If users press cross at top, closes box
        self.confirmation_box.protocol('WM_DELETE_WINDOW', partial(self.close_confirmation))

        # confirmation frame
        self.confirmation_frame = Frame(width=400, height=500, pady=10, bg=background_colour)
        self.confirmation_frame.grid()

        # confirmation heading (row 0)
        self.confirmation_label = Label(self.confirmation_frame, text="Your booking has been confirmed.",
                                        padx=10, pady=10, font=("Arial", "20","bold"), bg=background_colour)
        self.confirmation_label.grid(row=0)

        # Confirmation text (row 1)
        self.confirmation_text_A = Label(self.confirmation_frame, text="Book again?",
                                         padx=10, font = ("Arial", "14"), bg=background_colour)
        self.confirmation_text_A.grid(row=1)

        # Buttons frame (row 2)
        self.confirmation_buttons_frame = Frame(self.confirmation_frame, bg=background_colour)
        self.confirmation_buttons_frame.grid(row=2, pady=10)

        # Confirm button (column 0)
        self.yes_button = Button(self.confirmation_buttons_frame, font="Arial 10 bold",
                                    text="Confirm", bg="dark blue", fg="white", padx=10, pady=10)
        self.yes_button.grid(row=0, column=0, padx=3)

        # Cancel button (column 1)
        self.no_button = Button(self.confirmation_buttons_frame, font="Arial 10 bold",
                                  text="Cancel", bg="dark blue", fg="white", padx=10, pady=10,
                                  command=partial(self.close_confirmation))
        self.no_button.grid(row=0, column=1, padx=3)

    def close_confirmation(self):
        self.confirmation_box.destroy()

if __name__ == "__main__":
    root = Tk()
    placeholder = Confirmation()
    root.mainloop()