from tkinter import *

# Version 2 // Completed formatting

# User Info
class Info:
    def __init__(self):
        # Formatting
        background_colour = "dark blue"

        # info frame
        self.info_frame = Frame(width=400, height=500, pady=10, bg=background_colour)
        self.info_frame.grid()

        # info heading (row 0)
        self.info_label = Label(self.info_frame, text="Massey University Overnighter",
                                 padx=10, pady=10, font=("Arial", "20","bold"),
                                 bg=background_colour, fg="white")
        self.info_label.grid(row=0)

        # Informational text (row 1)
        self.info_text = Label(self.info_frame, text="Please enter the following" 
                               " information to make your booking.", padx=10,
                               pady=10, font = ("Arial", "14"),
                               bg=background_colour, fg="white")
        self.info_text.grid(row=1)

        # First name entry label (row 2)
        self.fname_label = Label(self.info_frame, text="First Name:", padx=10, pady=10,
                                 font = ("Arial", "14", "italic"), bg=background_colour,
                                 fg="white")
        self.fname_label.grid(row=2)
        
        # First name entry box (row 3)
        self.fname_entry = Entry(self.info_frame, width=40, font="Arial 14 bold")
        self.fname_entry.grid(row=3, pady=10)

        # Last name entry label (row 4)
        self.lname_label = Label(self.info_frame, text="Last Name:", padx=10, pady=10,
                                 font = ("Arial", "14", "italic"), bg=background_colour,
                                 fg="white")
        self.lname_label.grid(row=4)
        
        # First name entry box (row 5)
        self.lname_entry = Entry(self.info_frame, width=40, font="Arial 14 bold")
        self.lname_entry.grid(row=5, pady=10)

        # Phone number entry label (row 6)
        self.phone_label = Label(self.info_frame, text="Phone Number:", padx=10, pady=10,
                                 font = ("Arial", "14", "italic"), bg=background_colour,
                                 fg="white")
        self.phone_label.grid(row=6)
        
        # Phone number entry box (row 7)
        self.phone_entry = Entry(self.info_frame, width=40, font="Arial 14 bold")
        self.phone_entry.grid(row=7, pady=10)

        # Auckland to Palmerston North button (row 8)
        self.a_to_pn_button = Button(self.info_frame, text="Auckland to Palmerston North",
                                  font="Arial 10 bold", bg="gold", padx=10, pady=10)
        self.a_to_pn_button.grid(row=8, pady=3)

        # Palmerston North to Auckland button (row 9)
        self.pn_to_a_button = Button(self.info_frame, text="Palmerston North to Auckland",
                                  font="Arial 10 bold", bg="gold", padx=10, pady=10)
        self.pn_to_a_button.grid(row=9, pady=3)

        # Book return button (row 10)
        self.return_button = Button(self.info_frame, text="Book Return",
                                  font="Arial 10 bold", bg="gold", padx=10, pady=10)
        self.return_button.grid(row=10, pady=3)

if __name__ == "__main__":
    root = Tk()
    root.title = "Massey University Overnighter"
    placeholder = Info()
    root.mainloop()